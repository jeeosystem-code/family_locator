package com.familyloc.app

import android.content.Context

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("family", Context.MODE_PRIVATE)

    fun setSession(c: Context, uid: String, familyId: String?, name: String) {
        p(c).edit().putString("uid", uid).putString("familyId", familyId).putString("name", name).apply()
    }

    fun clearFamily(c: Context) = p(c).edit().remove("familyId").putBoolean("sharing", false).apply()

    fun uid(c: Context): String? = p(c).getString("uid", null)
    fun familyId(c: Context): String? = p(c).getString("familyId", null)
    fun name(c: Context): String = p(c).getString("name", "Member") ?: "Member"

    fun setSharing(c: Context, on: Boolean) = p(c).edit().putBoolean("sharing", on).apply()
    fun sharing(c: Context): Boolean = p(c).getBoolean("sharing", false)
}
