package com.familyloc.app

import android.content.Context

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("family", Context.MODE_PRIVATE)

    // ---- groups (a person can be in several family groups)
    fun familyIds(c: Context): List<String> =
        (p(c).getString("ids", "") ?: "").split(",").filter { it.isNotBlank() }

    /** The group currently shown on the map / chat. */
    fun activeId(c: Context): String? = p(c).getString("active", null)

    fun setActive(c: Context, id: String) {
        p(c).edit().putString("active", id).apply()
    }

    fun setSession(c: Context, uid: String, ids: List<String>, name: String) {
        val current = activeId(c)
        val active = if (current != null && current in ids) current else ids.firstOrNull()
        p(c).edit()
            .putString("uid", uid)
            .putString("ids", ids.joinToString(","))
            .putString("active", active)
            .putString("name", name)
            .apply()
    }

    fun addFamily(c: Context, id: String) {
        val ids = familyIds(c).toMutableList()
        if (id !in ids) ids.add(id)
        p(c).edit().putString("ids", ids.joinToString(",")).putString("active", id).apply()
    }

    fun removeFamily(c: Context, id: String) {
        val ids = familyIds(c).filter { it != id }
        val current = activeId(c)
        val active = if (current != null && current != id) current else ids.firstOrNull()
        val e = p(c).edit().putString("ids", ids.joinToString(",")).putString("active", active)
        if (ids.isEmpty()) e.putBoolean("sharing", false)
        e.apply()
    }

    /** Used on sign-out. */
    fun clearFamily(c: Context) {
        p(c).edit().remove("ids").remove("active").putBoolean("sharing", false).apply()
    }

    // ---- person
    fun uid(c: Context): String? = p(c).getString("uid", null)
    fun name(c: Context): String = p(c).getString("name", "Member") ?: "Member"

    // ---- sharing + route recording
    fun setSharing(c: Context, on: Boolean) {
        p(c).edit().putBoolean("sharing", on).apply()
    }

    fun sharing(c: Context): Boolean = p(c).getBoolean("sharing", false)

    fun trailOn(c: Context): Boolean = p(c).getBoolean("trail", true)

    fun setTrailOn(c: Context, on: Boolean) {
        p(c).edit().putBoolean("trail", on).apply()
    }
}
