package com.familyloc.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restarts sharing after a reboot, but only if the person had sharing switched on. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (Prefs.sharing(context) && Prefs.familyIds(context).isNotEmpty()) {
            try {
                LocationService.start(context)
            } catch (e: Exception) {
                // Android may block background starts; sharing resumes when the app is opened.
            }
        }
    }
}
