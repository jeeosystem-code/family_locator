package com.familyloc.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.TilesOverlay
import java.io.File

/** Whose route the Route screen should show (set by the map screen before opening it). */
object RouteTarget {
    var fid: String = ""
    var uid: String = ""
    var name: String = ""
}

class Stop(val lat: Double, val lng: Double, val startTs: Long, val endTs: Long)
class RouteStats(val km: Double, val movingMs: Long, val stops: List<Stop>)
private class Pos(val lat: Double, val lng: Double, val speedKmh: Double, val idle: Boolean)
private class Layers(val key: Any, val done: Polyline, val mover: Marker)

private const val GAP_MS = 12 * 60_000L
private const val STOP_MIN_MS = 10 * 60_000L

// ------------------------------------------------------------------ maths

private fun dist(a: TrailPoint, b: TrailPoint): Float {
    val r = FloatArray(1)
    android.location.Location.distanceBetween(a.lat, a.lng, b.lat, b.lng, r)
    return r[0]
}

/** Distance, time moving and stops (staying within ~80 m for 10+ minutes). */
fun analyze(points: List<TrailPoint>): RouteStats {
    var meters = 0.0
    var moving = 0L
    for (i in 1 until points.size) {
        val d = dist(points[i - 1], points[i])
        val dt = points[i].ts - points[i - 1].ts
        if (d > 30f) {
            meters += d
            if (dt <= GAP_MS) moving += dt
        }
    }
    val stops = mutableListOf<Stop>()
    var i = 0
    while (i < points.size) {
        var j = i
        while (j + 1 < points.size && dist(points[i], points[j + 1]) < 80f) j++
        if (points[j].ts - points[i].ts >= STOP_MIN_MS) {
            stops.add(Stop(points[i].lat, points[i].lng, points[i].ts, points[j].ts))
            i = j + 1
        } else {
            i++
        }
    }
    return RouteStats(meters / 1000.0, moving, stops)
}

/** Where the person was at time [t], found by sliding between the two nearest recorded points. */
private fun posAt(p: List<TrailPoint>, t: Long): Pos {
    if (p.isEmpty()) return Pos(0.0, 0.0, 0.0, true)
    if (t <= p.first().ts) return Pos(p.first().lat, p.first().lng, 0.0, true)
    if (t >= p.last().ts) return Pos(p.last().lat, p.last().lng, 0.0, true)
    var lo = 0
    var hi = p.size - 1
    while (lo < hi) {
        val mid = (lo + hi + 1) / 2
        if (p[mid].ts <= t) lo = mid else hi = mid - 1
    }
    val a = p[lo]
    val b = p[lo + 1]
    val dt = b.ts - a.ts
    if (dt <= 0L || dt > GAP_MS) return Pos(a.lat, a.lng, 0.0, true)
    val d = dist(a, b)
    val f = (t - a.ts).toDouble() / dt
    val speed = if (d < 30f) 0.0 else d / (dt / 1000.0) * 3.6
    return Pos(a.lat + (b.lat - a.lat) * f, a.lng + (b.lng - a.lng) * f, speed, d < 60f)
}

private fun traveled(p: List<TrailPoint>, t: Long, cur: Pos): List<GeoPoint> {
    val out = ArrayList<GeoPoint>()
    for (pt in p) {
        if (pt.ts <= t) out.add(GeoPoint(pt.lat, pt.lng)) else break
    }
    out.add(GeoPoint(cur.lat, cur.lng))
    return out
}

private fun dayRange(offset: Int): Pair<Long, Long> {
    val c = java.util.Calendar.getInstance()
    c.add(java.util.Calendar.DAY_OF_YEAR, -offset)
    c.set(java.util.Calendar.HOUR_OF_DAY, 0)
    c.set(java.util.Calendar.MINUTE, 0)
    c.set(java.util.Calendar.SECOND, 0)
    c.set(java.util.Calendar.MILLISECOND, 0)
    val start = c.timeInMillis
    return start to (start + 24L * 60L * 60L * 1000L)
}

private fun dayLabel(offset: Int): String = when (offset) {
    0 -> "Today"
    1 -> "Yesterday"
    else -> {
        val c = java.util.Calendar.getInstance()
        c.add(java.util.Calendar.DAY_OF_YEAR, -offset)
        java.text.SimpleDateFormat("EEE d MMM", java.util.Locale.getDefault()).format(c.time)
    }
}

private fun duration(ms: Long): String {
    val m = ms / 60_000L
    return if (m < 60) "$m min" else "${m / 60} h ${m % 60} min"
}

// ------------------------------------------------------------------ map pieces

private fun badgeIcon(ctx: Context, text: String, argb: Int, dp: Int = 26): Drawable {
    val d = ctx.resources.displayMetrics.density
    val s = (dp * d).toInt()
    val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
    val cv = Canvas(bmp)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    val r = s / 2f
    p.color = android.graphics.Color.WHITE
    cv.drawCircle(r, r, r, p)
    p.color = argb
    cv.drawCircle(r, r, r - 2 * d, p)
    p.color = android.graphics.Color.WHITE
    p.textSize = dp * 0.5f * d
    p.typeface = android.graphics.Typeface.DEFAULT_BOLD
    p.textAlign = Paint.Align.CENTER
    val y = r - (p.descent() + p.ascent()) / 2
    cv.drawText(text, r, y, p)
    return BitmapDrawable(ctx.resources, bmp)
}

private fun fitTo(map: MapView, geo: List<GeoPoint>) {
    if (geo.isEmpty()) return
    val box = BoundingBox.fromGeoPoints(geo)
    if (geo.size >= 2 && (box.latitudeSpan > 0.0001 || box.longitudeSpan > 0.0001)) {
        map.zoomToBoundingBox(box, false, 120)
    } else {
        map.controller.setZoom(17.0)
        map.controller.setCenter(geo.first())
    }
}

private fun buildLayers(
    map: MapView,
    points: List<TrailPoint>,
    stops: List<Stop>,
    name: String,
    fmt: java.text.SimpleDateFormat
): Layers {
    val ctx = map.context
    map.overlays.clear()
    val geo = points.map { GeoPoint(it.lat, it.lng) }

    val all = Polyline(map)
    all.setPoints(geo)
    all.outlinePaint.color = android.graphics.Color.argb(150, 156, 163, 175)
    all.outlinePaint.strokeWidth = 10f
    map.overlays.add(all)

    val done = Polyline(map)
    done.outlinePaint.color = android.graphics.Color.rgb(37, 99, 235)
    done.outlinePaint.strokeWidth = 13f
    map.overlays.add(done)

    stops.forEachIndexed { i, s ->
        val mk = Marker(map)
        mk.position = GeoPoint(s.lat, s.lng)
        mk.icon = badgeIcon(ctx, "${i + 1}", android.graphics.Color.rgb(245, 158, 11))
        mk.title = "Stop ${i + 1}"
        mk.snippet = "${fmt.format(java.util.Date(s.startTs))} – ${fmt.format(java.util.Date(s.endTs))}"
        mk.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
        map.overlays.add(mk)
    }

    val start = Marker(map)
    start.position = geo.first()
    start.icon = badgeIcon(ctx, "S", android.graphics.Color.rgb(22, 163, 74))
    start.title = "Start"
    start.snippet = fmt.format(java.util.Date(points.first().ts))
    start.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
    map.overlays.add(start)

    val end = Marker(map)
    end.position = geo.last()
    end.icon = badgeIcon(ctx, "E", android.graphics.Color.rgb(220, 38, 38))
    end.title = "Latest point"
    end.snippet = fmt.format(java.util.Date(points.last().ts))
    end.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
    map.overlays.add(end)

    val mover = Marker(map)
    mover.icon = avatarIcon(ctx, name, avatarColor(name).toArgb())
    mover.title = name
    mover.position = geo.first()
    mover.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
    map.overlays.add(mover)

    fitTo(map, geo)
    return Layers(points, done, mover)
}

// ------------------------------------------------------------------ UI

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(12.dp)
    ) {
        Text(value, style = MaterialTheme.typography.titleMedium)
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
    }
}

@Composable
fun RouteScreen(onBack: () -> Unit) {
    val name = RouteTarget.name
    val dark = isSystemInDarkTheme()
    val fmt = remember { java.text.SimpleDateFormat("h:mm a", java.util.Locale.getDefault()) }

    var dayOffset by remember { mutableStateOf(0) }
    var reload by remember { mutableStateOf(0) }
    var loading by remember { mutableStateOf(true) }
    var points by remember { mutableStateOf<List<TrailPoint>>(emptyList()) }
    var curTs by remember { mutableStateOf(0L) }
    var playing by remember { mutableStateOf(false) }
    var speedIdx by remember { mutableStateOf(1) }
    var follow by remember { mutableStateOf(true) }
    var fitTick by remember { mutableStateOf(0) }
    var centerTick by remember { mutableStateOf(0) }
    var centerAt by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    val seenFit = remember { intArrayOf(0) }
    val seenCenter = remember { intArrayOf(0) }

    val stats = remember(points) { analyze(points) }
    val startTs = points.firstOrNull()?.ts ?: 0L
    val endTs = points.lastOrNull()?.ts ?: 0L
    val hasRoute = points.size >= 2 && endTs > startTs

    BackHandler { onBack() }

    LaunchedEffect(dayOffset, reload) {
        loading = true
        playing = false
        val (from, to) = dayRange(dayOffset)
        points = try {
            Repo.loadTrail(RouteTarget.fid, RouteTarget.uid, from, to)
        } catch (e: Exception) {
            emptyList()
        }
        curTs = points.firstOrNull()?.ts ?: 0L
        loading = false
    }

    // Playback: advance time every frame. Quiet stretches (standing still) are skipped faster.
    LaunchedEffect(playing, speedIdx, points) {
        if (!playing || !hasRoute) return@LaunchedEffect
        var last = withFrameNanos { it }
        while (playing) {
            val nowNs = withFrameNanos { it }
            val dtMs = (nowNs - last) / 1_000_000L
            last = nowNs
            val minutesPerSecond = listOf(6, 20, 60)[speedIdx]
            val idleBoost = if (posAt(points, curTs).idle) 6L else 1L
            val virtualPerSecond = minutesPerSecond * 60_000L * idleBoost
            curTs = minOf(endTs, curTs + dtMs * virtualPerSecond / 1000L)
            if (curTs >= endTs) playing = false
        }
    }

    val cur = posAt(points, curTs)

    Column(Modifier.fillMaxSize()) {
        // ---------------- map
        Box(Modifier.fillMaxWidth().weight(1f)) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    val cfg = Configuration.getInstance()
                    cfg.userAgentValue = c.packageName
                    cfg.osmdroidBasePath = c.cacheDir
                    cfg.osmdroidTileCache = File(c.cacheDir, "tiles")
                    MapView(c).apply {
                        setTileSource(TileSourceFactory.MAPNIK)
                        setMultiTouchControls(true)
                        controller.setZoom(15.0)
                        controller.setCenter(GeoPoint(20.5937, 78.9629))
                    }
                },
                update = { map ->
                    map.overlayManager.tilesOverlay.setColorFilter(if (dark) TilesOverlay.INVERT_COLORS else null)
                    if (points.isEmpty()) {
                        map.overlays.clear()
                        map.tag = null
                    } else {
                        val existing = map.tag as? Layers
                        val layers: Layers =
                            if (existing != null && existing.key === points) existing
                            else buildLayers(map, points, stats.stops, name, fmt).also { map.tag = it }
                        layers.done.setPoints(traveled(points, curTs, cur))
                        layers.mover.position = GeoPoint(cur.lat, cur.lng)
                        if (follow && playing) map.controller.setCenter(GeoPoint(cur.lat, cur.lng))
                        if (seenCenter[0] != centerTick) {
                            seenCenter[0] = centerTick
                            centerAt?.let { (la, ln) ->
                                map.controller.setZoom(16.0)
                                map.controller.animateTo(GeoPoint(la, ln))
                            }
                        }
                        if (seenFit[0] != fitTick) {
                            seenFit[0] = fitTick
                            fitTo(map, points.map { GeoPoint(it.lat, it.lng) })
                        }
                    }
                    map.invalidate()
                }
            )
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.background.copy(alpha = 0.92f),
                shadowElevation = 4.dp,
                modifier = Modifier.align(Alignment.TopStart).padding(12.dp)
            ) {
                Row(
                    Modifier.clickable { onBack() }.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) { Text("← Back", style = MaterialTheme.typography.labelLarge) }
            }
            if (hasRoute) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.background.copy(alpha = 0.92f),
                    shadowElevation = 4.dp,
                    modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)
                ) {
                    Row(
                        Modifier.clickable { fitTick += 1 }.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) { Text("Fit route", style = MaterialTheme.typography.labelLarge) }
                }
            }
            Text(
                "© OpenStreetMap contributors", fontSize = 10.sp, color = Color(0xFF333333),
                modifier = Modifier.align(Alignment.BottomEnd)
                    .background(Color.White.copy(alpha = 0.75f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }

        // ---------------- controls panel
        Surface(
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            color = MaterialTheme.colorScheme.background,
            shadowElevation = 12.dp,
            modifier = Modifier.fillMaxWidth().heightIn(max = 440.dp)
        ) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp)) {
                // Title + refresh
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(avatarColor(name)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            name.trim().take(1).uppercase().ifEmpty { "?" },
                            color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("$name's route", style = MaterialTheme.typography.titleLarge)
                        Text(
                            if (hasRoute) "${fmt.format(java.util.Date(startTs))} – ${fmt.format(java.util.Date(endTs))}"
                            else dayLabel(dayOffset),
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                        )
                    }
                    TextButton(onClick = { reload += 1 }) { Text("↻ Refresh") }
                }

                // Day picker (last 7 days)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (off in 0..6) {
                        GroupChip(dayLabel(off), selected = dayOffset == off) { dayOffset = off }
                    }
                }

                if (loading) {
                    Text(
                        "Loading route…",
                        modifier = Modifier.padding(vertical = 24.dp),
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                    )
                } else if (!hasRoute) {
                    Text(
                        "No route recorded for ${dayLabel(dayOffset).lowercase()}.",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(top = 20.dp)
                    )
                    Text(
                        "A route is recorded while the person's sharing is on and \"Record my route\" is switched on.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                        modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                    )
                } else {
                    // Current time + speed
                    Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            fmt.format(java.util.Date(curTs)),
                            fontSize = 30.sp, fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(
                            if (cur.speedKmh < 1.0) "Standing still" else "%.0f km/h".format(cur.speedKmh),
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                    }

                    // Time slider
                    Slider(
                        value = (curTs - startTs).toFloat(),
                        onValueChange = { v ->
                            playing = false
                            curTs = startTs + v.toLong()
                        },
                        valueRange = 0f..(endTs - startTs).toFloat()
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(fmt.format(java.util.Date(startTs)), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                        Text(fmt.format(java.util.Date(endTs)), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    }

                    // Play / speed / follow
                    Spacer(Modifier.height(10.dp))
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                if (playing) {
                                    playing = false
                                } else {
                                    if (curTs >= endTs) curTs = startTs
                                    playing = true
                                }
                            },
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Text(
                                when {
                                    playing -> "⏸ Pause"
                                    curTs >= endTs -> "↻ Replay"
                                    else -> "▶ Play"
                                }
                            )
                        }
                        listOf("Slow", "Normal", "Fast").forEachIndexed { i, label ->
                            GroupChip(label, selected = speedIdx == i) { speedIdx = i }
                        }
                        GroupChip("📍 Follow", selected = follow) { follow = !follow }
                    }

                    // Summary tiles
                    Spacer(Modifier.height(14.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatTile("Distance", "%.1f km".format(stats.km), Modifier.weight(1f))
                        StatTile("Moving", duration(stats.movingMs), Modifier.weight(1f))
                        StatTile("Stops", "${stats.stops.size}", Modifier.weight(1f))
                    }

                    // Stops
                    if (stats.stops.isNotEmpty()) {
                        Spacer(Modifier.height(14.dp))
                        Text("Stops", style = MaterialTheme.typography.titleLarge)
                        Text(
                            "Tap a stop to jump there",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                        Spacer(Modifier.height(4.dp))
                        stats.stops.forEachIndexed { i, s ->
                            Row(
                                Modifier.fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable {
                                        playing = false
                                        curTs = s.startTs
                                        centerAt = s.lat to s.lng
                                        centerTick += 1
                                    }
                                    .padding(horizontal = 8.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    Modifier.size(32.dp).clip(CircleShape).background(Color(0xFFF59E0B)),
                                    contentAlignment = Alignment.Center
                                ) { Text("${i + 1}", color = Color.White, fontWeight = FontWeight.Bold) }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("Stayed about ${duration(s.endTs - s.startTs)}", style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        "${fmt.format(java.util.Date(s.startTs))} – ${fmt.format(java.util.Date(s.endTs))}",
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                                    )
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }
}
