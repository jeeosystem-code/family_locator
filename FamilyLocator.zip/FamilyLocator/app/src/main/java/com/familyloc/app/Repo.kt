package com.familyloc.app

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

data class Member(
    val uid: String,
    val name: String,
    val lat: Double?,
    val lng: Double?,
    val battery: Int?,
    val updatedAt: Long?,
    val sharing: Boolean
)

data class Message(
    val id: String,
    val uid: String,
    val name: String,
    val text: String,
    val ts: Long?
)

enum class Screen { Loading, Auth, Consent, Family, Map, Chat }

object Repo {
    private val auth get() = FirebaseAuth.getInstance()
    private val db get() = FirebaseFirestore.getInstance()
    private const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

    private fun newCode() = (1..6).map { ALPHABET.random() }.joinToString("")

    private fun family(fid: String) = db.collection("families").document(fid)

    suspend fun signUp(ctx: Context, name: String, email: String, password: String) {
        val res = auth.createUserWithEmailAndPassword(email.trim(), password).await()
        val uid = res.user!!.uid
        db.collection("users").document(uid)
            .set(mapOf("name" to name.trim(), "consent" to false), SetOptions.merge()).await()
        Prefs.setSession(ctx, uid, emptyList(), name.trim())
    }

    suspend fun signIn(email: String, password: String) {
        auth.signInWithEmailAndPassword(email.trim(), password).await()
    }

    suspend fun initialScreen(ctx: Context): Screen {
        val user = auth.currentUser ?: return Screen.Auth
        val ref = db.collection("users").document(user.uid)
        val doc = ref.get().await()
        val name = doc.getString("name") ?: "Member"
        val ids = (doc.get("familyIds") as? List<*>)?.filterIsInstance<String>()?.toMutableList()
            ?: mutableListOf()
        // Older versions stored a single "familyId": fold it into the list.
        val legacy = doc.getString("familyId")
        if (legacy != null && legacy !in ids) {
            ids.add(legacy)
            ref.set(mapOf("familyIds" to ids), SetOptions.merge()).await()
        }
        Prefs.setSession(ctx, user.uid, ids, name)
        return when {
            doc.getBoolean("consent") != true -> Screen.Consent
            ids.isEmpty() -> Screen.Family
            else -> Screen.Map
        }
    }

    suspend fun saveConsent() {
        val uid = auth.currentUser!!.uid
        db.collection("users").document(uid)
            .set(mapOf("consent" to true, "consentAt" to FieldValue.serverTimestamp()), SetOptions.merge())
            .await()
    }

    suspend fun createFamily(ctx: Context, familyName: String): String {
        val uid = auth.currentUser!!.uid
        val code = newCode()
        val ref = db.collection("families").document()
        ref.set(
            mapOf("name" to familyName.trim(), "code" to code, "members" to listOf(uid), "createdBy" to uid)
        ).await()
        db.collection("invites").document(code).set(mapOf("familyId" to ref.id)).await()
        db.collection("users").document(uid)
            .set(mapOf("familyIds" to FieldValue.arrayUnion(ref.id)), SetOptions.merge()).await()
        Prefs.addFamily(ctx, ref.id)
        return code
    }

    suspend fun joinFamily(ctx: Context, code: String) {
        val uid = auth.currentUser!!.uid
        val inv = db.collection("invites").document(code.trim().uppercase()).get().await()
        val fid = inv.getString("familyId") ?: throw IllegalArgumentException("Invalid family code")
        family(fid).update("members", FieldValue.arrayUnion(uid)).await()
        db.collection("users").document(uid)
            .set(mapOf("familyIds" to FieldValue.arrayUnion(fid)), SetOptions.merge()).await()
        Prefs.addFamily(ctx, fid)
    }

    suspend fun familyCode(fid: String): String =
        family(fid).get().await().getString("code") ?: ""

    suspend fun familyNames(ids: List<String>): Map<String, String> {
        val out = mutableMapOf<String, String>()
        for (id in ids) {
            out[id] = try { family(id).get().await().getString("name") ?: "Family" } catch (e: Exception) { "Family" }
        }
        return out
    }

    /** Writes the sharing on/off flag to every group this person is in. */
    suspend fun setSharingFlag(ctx: Context, on: Boolean) {
        val uid = Prefs.uid(ctx) ?: return
        for (fid in Prefs.familyIds(ctx)) {
            family(fid).collection("locations").document(uid)
                .set(mapOf("name" to Prefs.name(ctx), "sharing" to on), SetOptions.merge()).await()
        }
    }

    /** Asks another member's phone to send a fresh location right now. */
    suspend fun requestRefresh(fid: String, targetUid: String) {
        family(fid).collection("locations").document(targetUid)
            .update("refreshRequestedAt", FieldValue.serverTimestamp()).await()
    }

    /** Leaves one group and removes this person's live location and route history from it. */
    suspend fun leaveFamily(ctx: Context, fid: String) {
        val uid = Prefs.uid(ctx) ?: return
        val loc = family(fid).collection("locations").document(uid)
        val trail = loc.collection("trail")
        while (true) {
            val snap = trail.limit(400).get().await()
            if (snap.isEmpty) break
            val batch = db.batch()
            snap.documents.forEach { batch.delete(it.reference) }
            batch.commit().await()
        }
        loc.delete().await()
        family(fid).update("members", FieldValue.arrayRemove(uid)).await()
        db.collection("users").document(uid)
            .set(mapOf("familyIds" to FieldValue.arrayRemove(fid), "familyId" to FieldValue.delete()), SetOptions.merge())
            .await()
        Prefs.removeFamily(ctx, fid)
    }

    fun signOut(ctx: Context) {
        auth.signOut()
        Prefs.clearFamily(ctx)
    }

    fun observeMembers(fid: String) = callbackFlow<List<Member>> {
        val reg = family(fid).collection("locations")
            .addSnapshotListener { snap, _ ->
                if (snap != null) {
                    trySend(snap.documents.map { d ->
                        Member(
                            uid = d.id,
                            name = d.getString("name") ?: "Member",
                            lat = d.getDouble("lat"),
                            lng = d.getDouble("lng"),
                            battery = d.getLong("battery")?.toInt(),
                            updatedAt = d.getTimestamp("updatedAt")?.toDate()?.time,
                            sharing = d.getBoolean("sharing") == true
                        )
                    })
                }
            }
        awaitClose { reg.remove() }
    }

    // ------------------------------------------------------------ route history

    /** Route points (lat, lng) recorded for a member since [sinceMs], oldest first. */
    suspend fun loadTrail(fid: String, uid: String, sinceMs: Long): List<Pair<Double, Double>> {
        val snap = family(fid).collection("locations").document(uid).collection("trail")
            .whereGreaterThan("ts", sinceMs).orderBy("ts").limit(1500).get().await()
        return snap.documents.mapNotNull { d ->
            val la = d.getDouble("lat")
            val ln = d.getDouble("lng")
            if (la != null && ln != null) la to ln else null
        }
    }

    // ------------------------------------------------------------ chat

    suspend fun sendMessage(ctx: Context, fid: String, text: String) {
        val uid = Prefs.uid(ctx) ?: return
        val t = text.trim().take(500)
        if (t.isEmpty()) return
        family(fid).collection("messages").add(
            mapOf(
                "uid" to uid,
                "name" to Prefs.name(ctx),
                "text" to t,
                "ts" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    fun observeMessages(fid: String) = callbackFlow<List<Message>> {
        val reg = family(fid).collection("messages").orderBy("ts").limitToLast(100)
            .addSnapshotListener { snap, _ ->
                if (snap != null) {
                    trySend(snap.documents.map { d ->
                        Message(
                            id = d.id,
                            uid = d.getString("uid") ?: "",
                            name = d.getString("name") ?: "Member",
                            text = d.getString("text") ?: "",
                            ts = d.getTimestamp("ts", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                                ?.toDate()?.time
                        )
                    })
                }
            }
        awaitClose { reg.remove() }
    }
}
