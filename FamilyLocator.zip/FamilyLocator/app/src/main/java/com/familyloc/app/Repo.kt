package com.familyloc.app

import android.content.Context
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

data class Member(
    val uid: String,
    val name: String,
    val lat: Double?,
    val lng: Double?,
    val battery: Int?,
    val updatedAt: Long?,
    val sharing: Boolean
)

enum class Screen { Loading, Auth, Consent, Family, Map }

object Repo {
    private val auth get() = FirebaseAuth.getInstance()
    private val db get() = FirebaseFirestore.getInstance()
    private const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

    private fun newCode() = (1..6).map { ALPHABET.random() }.joinToString("")

    suspend fun signUp(ctx: Context, name: String, email: String, password: String) {
        val res = auth.createUserWithEmailAndPassword(email.trim(), password).await()
        val uid = res.user!!.uid
        db.collection("users").document(uid)
            .set(mapOf("name" to name.trim(), "consent" to false), SetOptions.merge()).await()
        Prefs.setSession(ctx, uid, null, name.trim())
    }

    suspend fun signIn(email: String, password: String) {
        auth.signInWithEmailAndPassword(email.trim(), password).await()
    }

    suspend fun initialScreen(ctx: Context): Screen {
        val user = auth.currentUser ?: return Screen.Auth
        val doc = db.collection("users").document(user.uid).get().await()
        val name = doc.getString("name") ?: "Member"
        val fid = doc.getString("familyId")
        Prefs.setSession(ctx, user.uid, fid, name)
        return when {
            doc.getBoolean("consent") != true -> Screen.Consent
            fid == null -> Screen.Family
            else -> Screen.Map
        }
    }

    suspend fun saveConsent() {
        val uid = auth.currentUser!!.uid
        db.collection("users").document(uid)
            .set(mapOf("consent" to true, "consentAt" to FieldValue.serverTimestamp()), SetOptions.merge())
            .await()
    }

    suspend fun createFamily(ctx: Context, familyName: String): String {
        val uid = auth.currentUser!!.uid
        val code = newCode()
        val ref = db.collection("families").document()
        ref.set(
            mapOf("name" to familyName.trim(), "code" to code, "members" to listOf(uid), "createdBy" to uid)
        ).await()
        db.collection("invites").document(code).set(mapOf("familyId" to ref.id)).await()
        db.collection("users").document(uid).set(mapOf("familyId" to ref.id), SetOptions.merge()).await()
        Prefs.setSession(ctx, uid, ref.id, Prefs.name(ctx))
        return code
    }

    suspend fun joinFamily(ctx: Context, code: String) {
        val uid = auth.currentUser!!.uid
        val inv = db.collection("invites").document(code.trim().uppercase()).get().await()
        val fid = inv.getString("familyId") ?: throw IllegalArgumentException("Invalid family code")
        db.collection("families").document(fid).update("members", FieldValue.arrayUnion(uid)).await()
        db.collection("users").document(uid).set(mapOf("familyId" to fid), SetOptions.merge()).await()
        Prefs.setSession(ctx, uid, fid, Prefs.name(ctx))
    }

    suspend fun familyCode(fid: String): String =
        db.collection("families").document(fid).get().await().getString("code") ?: ""

    suspend fun setSharingFlag(ctx: Context, on: Boolean) {
        val uid = Prefs.uid(ctx) ?: return
        val fid = Prefs.familyId(ctx) ?: return
        db.collection("families").document(fid).collection("locations").document(uid)
            .set(mapOf("name" to Prefs.name(ctx), "sharing" to on), SetOptions.merge()).await()
    }

    suspend fun leaveFamily(ctx: Context) {
        val uid = Prefs.uid(ctx) ?: return
        val fid = Prefs.familyId(ctx) ?: return
        db.collection("families").document(fid).collection("locations").document(uid).delete().await()
        db.collection("families").document(fid).update("members", FieldValue.arrayRemove(uid)).await()
        db.collection("users").document(uid).update("familyId", FieldValue.delete()).await()
        Prefs.clearFamily(ctx)
    }

    fun signOut(ctx: Context) {
        auth.signOut()
        Prefs.clearFamily(ctx)
    }

    fun observeMembers(fid: String) = callbackFlow<List<Member>> {
        val reg = db.collection("families").document(fid).collection("locations")
            .addSnapshotListener { snap, _ ->
                if (snap != null) {
                    trySend(snap.documents.map { d ->
                        Member(
                            uid = d.id,
                            name = d.getString("name") ?: "Member",
                            lat = d.getDouble("lat"),
                            lng = d.getDouble("lng"),
                            battery = d.getLong("battery")?.toInt(),
                            updatedAt = d.getTimestamp("updatedAt")?.toDate()?.time,
                            sharing = d.getBoolean("sharing") == true
                        )
                    })
                }
            }
        awaitClose { reg.remove() }
    }
}
