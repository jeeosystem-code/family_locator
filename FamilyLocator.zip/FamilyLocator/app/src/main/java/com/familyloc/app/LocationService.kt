package com.familyloc.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.BatteryManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions

/**
 * Foreground service that shares this phone's location with every family group the person is in,
 * records a sparse route trail, answers "refresh" taps, and shows chat notifications.
 * Always shows a notification while running.
 */
class LocationService : Service() {

    private val client by lazy { LocationServices.getFusedLocationProviderClient(this) }
    private val handler = Handler(Looper.getMainLooper())
    private val regs = mutableListOf<ListenerRegistration>()

    private var lastTrail: Location? = null
    private var lastTrailAt = 0L

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            result.lastLocation?.let { push(it) }
        }
    }

    private val heartbeat = object : Runnable {
        @SuppressLint("MissingPermission")
        override fun run() {
            client.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, null)
                .addOnSuccessListener { loc -> loc?.let { push(it) } }
            handler.postDelayed(this, 60_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Location sharing", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(MSG_CHANNEL, "Family chat", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Prefs.setSharing(this, false)
            if (intent?.getBooleanExtra(EXTRA_SILENT, false) != true) markPaused()
            stopSelf()
            return START_NOT_STICKY
        }
        val type = if (android.os.Build.VERSION.SDK_INT >= 29)
            ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0
        ServiceCompat.startForeground(this, 1, buildNotification(), type)
        startUpdates()
        return START_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun startUpdates() {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted || Prefs.familyIds(this).isEmpty()) {
            stopSelf()
            return
        }
        val req = LocationRequest.Builder(Priority.PRIORITY_BALANCED_POWER_ACCURACY, 60_000L)
            .setMinUpdateIntervalMillis(30_000L)
            .build()
        client.requestLocationUpdates(req, callback, mainLooper)
        // Heartbeat: even if the phone is standing still, send a fresh location every minute.
        handler.removeCallbacks(heartbeat)
        handler.postDelayed(heartbeat, 60_000L)
        listenToGroups()
    }

    /** One refresh listener and one chat listener per group. Re-run whenever groups change. */
    private fun listenToGroups() {
        regs.forEach { it.remove() }
        regs.clear()
        val uid = Prefs.uid(this) ?: return
        val db = FirebaseFirestore.getInstance()

        for (fid in Prefs.familyIds(this)) {
            // "Tap a name" requests: send a fresh location immediately.
            var firstRefresh = true
            var lastRefresh = 0L
            regs += db.collection("families").document(fid)
                .collection("locations").document(uid)
                .addSnapshotListener { snap, _ ->
                    val t = snap?.getTimestamp("refreshRequestedAt")?.toDate()?.time
                    if (firstRefresh) {
                        firstRefresh = false
                        lastRefresh = t ?: 0L
                        return@addSnapshotListener
                    }
                    if (t != null && t != lastRefresh) {
                        lastRefresh = t
                        refreshNow()
                    }
                }

            // New chat messages from other people become notifications.
            var firstMessage = true
            regs += db.collection("families").document(fid).collection("messages")
                .orderBy("ts", Query.Direction.DESCENDING).limit(1)
                .addSnapshotListener { snap, _ ->
                    if (snap == null) return@addSnapshotListener
                    if (firstMessage) {
                        firstMessage = false
                        return@addSnapshotListener
                    }
                    for (change in snap.documentChanges) {
                        if (change.type != DocumentChange.Type.ADDED) continue
                        val d = change.document
                        if (d.getString("uid") == uid) continue
                        notifyMessage(d.getString("name") ?: "Family", d.getString("text") ?: "")
                    }
                }
        }
    }

    @SuppressLint("MissingPermission")
    private fun refreshNow() {
        client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
            .addOnSuccessListener { loc -> loc?.let { push(it) } }
    }

    private fun push(loc: Location) {
        val uid = Prefs.uid(this) ?: return
        val fids = Prefs.familyIds(this)
        if (fids.isEmpty()) return
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val battery = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val db = FirebaseFirestore.getInstance()

        val live = mapOf(
            "name" to Prefs.name(this),
            "lat" to loc.latitude,
            "lng" to loc.longitude,
            "accuracy" to loc.accuracy.toDouble(),
            "battery" to battery,
            "sharing" to true,
            "updatedAt" to FieldValue.serverTimestamp()
        )

        // Route trail is kept sparse (moved 50 m+, or every 10 min) to stay within free database limits.
        val nowMs = System.currentTimeMillis()
        val prev = lastTrail
        val addTrail = Prefs.trailOn(this) &&
            (prev == null || loc.distanceTo(prev) > 50f || nowMs - lastTrailAt > 10 * 60_000L)
        if (addTrail) {
            lastTrail = loc
            lastTrailAt = nowMs
        }
        val point = mapOf("lat" to loc.latitude, "lng" to loc.longitude, "ts" to nowMs)

        for (fid in fids) {
            val doc = db.collection("families").document(fid).collection("locations").document(uid)
            doc.set(live, SetOptions.merge())
            if (addTrail) doc.collection("trail").add(point)
        }
    }

    private fun markPaused() {
        val uid = Prefs.uid(this) ?: return
        val db = FirebaseFirestore.getInstance()
        for (fid in Prefs.familyIds(this)) {
            db.collection("families").document(fid)
                .collection("locations").document(uid)
                .set(mapOf("sharing" to false), SetOptions.merge())
        }
    }

    private fun notifyMessage(who: String, text: String) {
        val open = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, MSG_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle(who)
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        getSystemService(NotificationManager::class.java)
            .notify((System.currentTimeMillis() % 100_000L).toInt() + 100, n)
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, LocationService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Sharing location with your family")
            .setContentText("Tap to open. You can pause anytime.")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "Pause sharing", stop)
            .build()
    }

    override fun onDestroy() {
        handler.removeCallbacks(heartbeat)
        regs.forEach { it.remove() }
        regs.clear()
        client.removeLocationUpdates(callback)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL = "location_sharing"
        const val MSG_CHANNEL = "family_chat"
        const val ACTION_STOP = "com.familyloc.app.STOP"
        const val EXTRA_SILENT = "silent"

        fun start(ctx: Context) {
            Prefs.setSharing(ctx, true)
            ContextCompat.startForegroundService(ctx, Intent(ctx, LocationService::class.java))
        }

        /** silent = true skips writing "paused" to the database (used when leaving or signing out). */
        fun stop(ctx: Context, silent: Boolean = false) {
            ctx.startService(
                Intent(ctx, LocationService::class.java)
                    .setAction(ACTION_STOP)
                    .putExtra(EXTRA_SILENT, silent)
            )
        }
    }
}
