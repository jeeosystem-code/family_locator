package com.familyloc.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.BatteryManager
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions

/** Foreground service that shares this phone's location with the family. Always shows a notification. */
class LocationService : Service() {

    private val client by lazy { LocationServices.getFusedLocationProviderClient(this) }

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            result.lastLocation?.let { push(it) }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Location sharing", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Prefs.setSharing(this, false)
            if (intent?.getBooleanExtra(EXTRA_SILENT, false) != true) markPaused()
            stopSelf()
            return START_NOT_STICKY
        }
        val type = if (android.os.Build.VERSION.SDK_INT >= 29)
            ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0
        ServiceCompat.startForeground(this, 1, buildNotification(), type)
        startUpdates()
        return START_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun startUpdates() {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted) {
            stopSelf()
            return
        }
        val req = LocationRequest.Builder(Priority.PRIORITY_BALANCED_POWER_ACCURACY, 60_000L)
            .setMinUpdateIntervalMillis(30_000L)
            .build()
        client.requestLocationUpdates(req, callback, mainLooper)
        // Heartbeat: even if the phone is standing still, send a fresh location every minute.
        handler.removeCallbacks(heartbeat)
        handler.postDelayed(heartbeat, 60_000L)
        listenForRefresh()
    }

    private var refreshReg: ListenerRegistration? = null
    private var lastRefresh = 0L

    /** When another family member taps this person's name, send a fresh location immediately. */
    private fun listenForRefresh() {
        val uid = Prefs.uid(this) ?: return
        val fid = Prefs.familyId(this) ?: return
        refreshReg?.remove()
        var first = true
        refreshReg = FirebaseFirestore.getInstance()
            .collection("families").document(fid)
            .collection("locations").document(uid)
            .addSnapshotListener { snap, _ ->
                val t = snap?.getTimestamp("refreshRequestedAt")?.toDate()?.time
                if (first) {
                    first = false
                    lastRefresh = t ?: 0L
                    return@addSnapshotListener
                }
                if (t != null && t != lastRefresh) {
                    lastRefresh = t
                    refreshNow()
                }
            }
    }

    @SuppressLint("MissingPermission")
    private fun refreshNow() {
        client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
            .addOnSuccessListener { loc -> loc?.let { push(it) } }
    }

    private val handler = android.os.Handler(android.os.Looper.getMainLooper())

    private val heartbeat = object : Runnable {
        @SuppressLint("MissingPermission")
        override fun run() {
            client.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, null)
                .addOnSuccessListener { loc -> loc?.let { push(it) } }
            handler.postDelayed(this, 60_000L)
        }
    }

    private fun push(loc: android.location.Location) {
        val uid = Prefs.uid(this) ?: return
        val fid = Prefs.familyId(this) ?: return
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val battery = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        FirebaseFirestore.getInstance()
            .collection("families").document(fid)
            .collection("locations").document(uid)
            .set(
                mapOf(
                    "name" to Prefs.name(this),
                    "lat" to loc.latitude,
                    "lng" to loc.longitude,
                    "accuracy" to loc.accuracy.toDouble(),
                    "battery" to battery,
                    "sharing" to true,
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            )
    }

    private fun markPaused() {
        val uid = Prefs.uid(this) ?: return
        val fid = Prefs.familyId(this) ?: return
        FirebaseFirestore.getInstance()
            .collection("families").document(fid)
            .collection("locations").document(uid)
            .set(mapOf("sharing" to false), SetOptions.merge())
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, LocationService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Sharing location with your family")
            .setContentText("Tap to open. You can pause anytime.")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "Pause sharing", stop)
            .build()
    }

    override fun onDestroy() {
        handler.removeCallbacks(heartbeat)
        refreshReg?.remove()
        client.removeLocationUpdates(callback)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL = "location_sharing"
        const val ACTION_STOP = "com.familyloc.app.STOP"

        fun start(ctx: Context) {
            Prefs.setSharing(ctx, true)
            ContextCompat.startForegroundService(ctx, Intent(ctx, LocationService::class.java))
        }

        const val EXTRA_SILENT = "silent"

        /** silent = true skips writing "paused" to the database (used when leaving or signing out). */
        fun stop(ctx: Context, silent: Boolean = false) {
            ctx.startService(
                Intent(ctx, LocationService::class.java)
                    .setAction(ACTION_STOP)
                    .putExtra(EXTRA_SILENT, silent)
            )
        }
    }
}
