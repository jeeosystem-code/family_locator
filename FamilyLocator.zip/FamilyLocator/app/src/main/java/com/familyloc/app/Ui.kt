package com.familyloc.app

import android.Manifest
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.material3.SwitchDefaults
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.TilesOverlay
import java.io.File

private val AvatarColors = listOf(
    Color(0xFF0F766E), Color(0xFF7C3AED), Color(0xFFDB2777),
    Color(0xFFEA580C), Color(0xFF2563EB), Color(0xFF16A34A)
)
private val LiveGreen = Color(0xFF16A34A)
private val StaleAmber = Color(0xFFF59E0B)
private val OffGrey = Color(0xFF9CA3AF)

fun avatarColor(name: String) = AvatarColors[(name.hashCode() and 0x7fffffff) % AvatarColors.size]

/** Round initial-letter map marker with a small tail, matching the family list avatars. */
fun avatarIcon(ctx: android.content.Context, name: String, argb: Int): android.graphics.drawable.Drawable {
    val d = ctx.resources.displayMetrics.density
    val size = (44 * d).toInt()
    val tail = (9 * d).toInt()
    val bmp = android.graphics.Bitmap.createBitmap(size, size + tail, android.graphics.Bitmap.Config.ARGB_8888)
    val cv = android.graphics.Canvas(bmp)
    val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    val r = size / 2f
    p.color = android.graphics.Color.WHITE
    cv.drawCircle(r, r, r, p)
    val tri = android.graphics.Path().apply {
        moveTo(r - 7 * d, size - 4 * d)
        lineTo(r + 7 * d, size - 4 * d)
        lineTo(r, size + tail.toFloat())
        close()
    }
    cv.drawPath(tri, p)
    p.color = argb
    cv.drawCircle(r, r, r - 3 * d, p)
    p.color = android.graphics.Color.WHITE
    p.textSize = 18 * d
    p.typeface = android.graphics.Typeface.DEFAULT_BOLD
    p.textAlign = android.graphics.Paint.Align.CENTER
    val y = r - (p.descent() + p.ascent()) / 2
    cv.drawText(name.trim().take(1).uppercase().ifEmpty { "?" }, r, y, p)
    return android.graphics.drawable.BitmapDrawable(ctx.resources, bmp)
}

// ---------------------------------------------------------------- app shell

@Composable
fun App() {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf(Screen.Loading) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        screen = try { Repo.initialScreen(ctx) } catch (e: Exception) { Screen.Auth }
    }

    Crossfade(targetState = screen, label = "screen") { s ->
        when (s) {
            Screen.Loading -> LoadingScreen()
            Screen.Auth -> AuthScreen {
                scope.launch {
                    screen = try { Repo.initialScreen(ctx) } catch (e: Exception) { Screen.Auth }
                }
            }
            Screen.Consent -> ConsentScreen { screen = Screen.Family }
            Screen.Family -> FamilyScreen(
                canCancel = Prefs.familyIds(ctx).isNotEmpty(),
                onCancel = { screen = Screen.Map },
                onDone = { screen = Screen.Map }
            )
            Screen.Map -> MapScreen(
                onLeft = { screen = Screen.Family },
                onSignOut = { screen = Screen.Auth },
                onChat = { screen = Screen.Chat },
                onAddGroup = { screen = Screen.Family },
                onRoute = { screen = Screen.Route }
            )
            Screen.Chat -> ChatScreen { screen = Screen.Map }
            Screen.Route -> RouteScreen { screen = Screen.Map }
        }
    }
}

// ---------------------------------------------------------------- shared pieces

@Composable
private fun BrandHeader(subtitle: String) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val logoScale by animateFloatAsState(
        if (shown) 1f else 0.55f, spring(dampingRatio = 0.45f, stiffness = 180f), label = "logoScale"
    )
    val logoAlpha by animateFloatAsState(if (shown) 1f else 0f, tween(500), label = "logoAlpha")
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(132.dp).graphicsLayer { scaleX = logoScale; scaleY = logoScale; alpha = logoAlpha }
                .background(
                    Brush.radialGradient(listOf(MaterialTheme.colorScheme.primary.copy(alpha = 0.28f), Color.Transparent)),
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Image(painterResource(R.drawable.ic_logo), contentDescription = null, modifier = Modifier.size(88.dp))
        }
        Spacer(Modifier.height(2.dp))
        Text(
            "Family Locator",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(4.dp))
        Text(
            subtitle,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun PrimaryButton(text: String, enabled: Boolean = true, busy: Boolean = false, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val off = MaterialTheme.colorScheme.onSurface
    val brush: Brush =
        if (enabled) Brush.horizontalGradient(listOf(BrandStart, BrandEnd)) else SolidColor(off.copy(alpha = 0.12f))
    Box(
        Modifier.fillMaxWidth().height(54.dp).clip(RoundedCornerShape(16.dp))
            .background(brush)
            .clickable(enabled = enabled && !busy) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        if (busy) {
            CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = Color.White)
        } else {
            Text(
                text,
                color = if (enabled) Color.White else off.copy(alpha = 0.38f),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp
            )
        }
    }
}

/** Soft teal wash at the top fading into the page, for the sign-in style screens. */
@Composable
private fun Modifier.backdrop(): Modifier = this.background(
    Brush.verticalGradient(
        listOf(MaterialTheme.colorScheme.primary.copy(alpha = 0.16f), MaterialTheme.colorScheme.background),
        endY = 1100f
    )
)

/** Status dot; a live member gets a soft pulsing ring. */
@Composable
private fun PulseDot(color: Color, live: Boolean) {
    Box(Modifier.size(20.dp), contentAlignment = Alignment.Center) {
        if (live) {
            val t = rememberInfiniteTransition(label = "pulse")
            val s by t.animateFloat(
                initialValue = 0.4f, targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(1500), RepeatMode.Restart), label = "pulseScale"
            )
            Box(
                Modifier.size(20.dp)
                    .graphicsLayer { scaleX = s; scaleY = s; alpha = ((1f - s) * 1.6f).coerceIn(0f, 1f) }
                    .clip(CircleShape).background(color)
            )
        }
        Box(Modifier.size(10.dp).clip(CircleShape).background(color))
    }
}

@Composable
private fun Field(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    keyboard: KeyboardOptions = KeyboardOptions.Default,
    password: Boolean = false
) {
    var show by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        keyboardOptions = keyboard,
        visualTransformation = if (password && !show) PasswordVisualTransformation() else VisualTransformation.None,
        trailingIcon = if (password) ({
            TextButton(onClick = { show = !show }) { Text(if (show) "Hide" else "Show") }
        }) else null,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(body, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f))
        }
    }
}

/** Small rounded pill used for group tabs and chat quick replies. */
@Composable
fun GroupChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Box(
        Modifier.clip(RoundedCornerShape(20.dp))
            .background(if (selected) scheme.primary else scheme.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(
            text,
            color = if (selected) scheme.onPrimary else scheme.onSurface,
            style = MaterialTheme.typography.labelLarge
        )
    }
}

private fun friendly(e: Exception): String {
    val m = (e.message ?: return "Something went wrong. Please try again.")
    val l = m.lowercase()
    return when {
        "network" in l -> "No internet connection. Please check and try again."
        "already in use" in l -> "This email already has an account. Try signing in instead."
        "password is invalid" in l || "no user record" in l || "credential" in l -> "Wrong email or password."
        "badly formatted" in l -> "Please enter a valid email address."
        else -> m
    }
}

// ---------------------------------------------------------------- screens

@Composable
fun LoadingScreen() {
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(painterResource(R.drawable.ic_logo), contentDescription = null, modifier = Modifier.size(96.dp))
        Spacer(Modifier.height(16.dp))
        CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
    }
}

@Composable
fun AuthScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isSignUp by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.fillMaxSize().backdrop().verticalScroll(rememberScrollState()).imePadding().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        BrandHeader("Private location sharing,\nfor your family only.")
        Spacer(Modifier.height(28.dp))
        Text(
            if (isSignUp) "Create your account" else "Welcome back",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        if (isSignUp) {
            Field(name, { name = it }, "Your name", KeyboardOptions(capitalization = KeyboardCapitalization.Words))
            Spacer(Modifier.height(10.dp))
        }
        Field(email, { email = it }, "Email", KeyboardOptions(keyboardType = KeyboardType.Email))
        Spacer(Modifier.height(10.dp))
        Field(
            password, { password = it }, "Password (6+ characters)",
            KeyboardOptions(keyboardType = KeyboardType.Password), password = true
        )
        error?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.fillMaxWidth())
        }
        info?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.primary, modifier = Modifier.fillMaxWidth())
        }
        if (!isSignUp) {
            TextButton(
                onClick = {
                    error = null; info = null
                    if (email.isBlank()) {
                        error = "Type your email above first, then tap Forgot password."
                    } else {
                        scope.launch {
                            try {
                                Repo.resetPassword(email)
                                info = "Reset link sent. Check your email (and spam folder)."
                            } catch (e: Exception) {
                                error = friendly(e)
                            }
                        }
                    }
                },
                modifier = Modifier.align(Alignment.End)
            ) { Text("Forgot password?") }
        }
        Spacer(Modifier.height(18.dp))
        PrimaryButton(
            text = if (isSignUp) "Create account" else "Sign in",
            enabled = email.isNotBlank() && password.length >= 6 && (!isSignUp || name.isNotBlank()),
            busy = busy
        ) {
            busy = true; error = null
            scope.launch {
                try {
                    if (isSignUp) Repo.signUp(ctx, name, email, password) else Repo.signIn(email, password)
                    onDone()
                } catch (e: Exception) {
                    error = friendly(e)
                }
                busy = false
            }
        }
        Spacer(Modifier.height(4.dp))
        TextButton(onClick = { isSignUp = !isSignUp; error = null; info = null }) {
            Text(if (isSignUp) "I already have an account" else "Create a new account")
        }
    }
}

@Composable
fun ConsentScreen(onAgree: () -> Unit) {
    val scope = rememberCoroutineScope()
    var agreed by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().backdrop()) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Your consent", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Please read this before you start. You decide what is shared.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
            InfoCard(
                "Shared with family only",
                "Your live location, battery level and today's route are shared with the members of your family groups, even when the app is closed."
            )
            InfoCard(
                "A notification stays on",
                "While sharing is on, a notification is always visible so you know it is running."
            )
            InfoCard(
                "You stay in control",
                "Pause sharing any time from the app or the notification. You can switch off route recording. Leave a group to remove your location and route history from it."
            )
            InfoCard(
                "Invite-only",
                "Only people who have your family code can join, and only members can see locations and chat."
            )
        }
        Column(Modifier.padding(horizontal = 24.dp, vertical = 12.dp)) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { agreed = !agreed },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(agreed, { agreed = it })
                Text("I understand and agree to share my location with my family group.", Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            PrimaryButton("I agree", enabled = agreed, busy = busy) {
                busy = true
                scope.launch {
                    try { Repo.saveConsent(); onAgree() } catch (e: Exception) { busy = false }
                }
            }
        }
    }
}

@Composable
fun FamilyScreen(canCancel: Boolean, onCancel: () -> Unit, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var familyName by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busyCreate by remember { mutableStateOf(false) }
    var busyJoin by remember { mutableStateOf(false) }
    var createdCode by remember { mutableStateOf<String?>(null) }

    BackHandler(enabled = canCancel) { onCancel() }

    // If sharing is already on, restart the service so it picks up the new group.
    fun finished() {
        if (Prefs.sharing(ctx)) LocationService.start(ctx)
        onDone()
    }

    Column(
        Modifier.fillMaxSize().backdrop().verticalScroll(rememberScrollState()).imePadding().padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        BrandHeader(
            if (canCancel) "Add another group, such as relatives or friends."
            else "Create your family group, or join one with a code."
        )
        Spacer(Modifier.height(24.dp))

        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("Start a new group", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(10.dp))
                Field(familyName, { familyName = it }, "Group name", KeyboardOptions(capitalization = KeyboardCapitalization.Words))
                Spacer(Modifier.height(12.dp))
                PrimaryButton("Create group", enabled = familyName.isNotBlank(), busy = busyCreate) {
                    busyCreate = true; error = null
                    scope.launch {
                        try {
                            val c = Repo.createFamily(ctx, familyName)
                            if (Prefs.sharing(ctx)) LocationService.start(ctx)
                            createdCode = c
                        } catch (e: Exception) { error = friendly(e) }
                        busyCreate = false
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("Join with a code", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(10.dp))
                Field(
                    code, { code = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(6) },
                    "6-character code",
                    KeyboardOptions(capitalization = KeyboardCapitalization.Characters)
                )
                Spacer(Modifier.height(12.dp))
                PrimaryButton("Join group", enabled = code.length == 6, busy = busyJoin) {
                    busyJoin = true; error = null
                    scope.launch {
                        try { Repo.joinFamily(ctx, code); finished() } catch (e: Exception) { error = friendly(e) }
                        busyJoin = false
                    }
                }
            }
        }
        error?.let {
            Spacer(Modifier.height(10.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }
        if (canCancel) {
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("Cancel") }
        }
    }

    createdCode?.let { c ->
        AlertDialog(
            onDismissRequest = { createdCode = null; onDone() },
            title = { Text("Group created 🎉") },
            text = {
                Column {
                    Text("Your invite code is")
                    Spacer(Modifier.height(6.dp))
                    Text(c, fontSize = 30.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("Send it to your family. They enter it after creating their account. You can find it again on the map screen.")
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(
                            Intent.EXTRA_TEXT,
                            "Join our family on Family Locator. Install the app and use this code: $c"
                        )
                    }
                    ctx.startActivity(Intent.createChooser(send, "Invite family"))
                    createdCode = null
                    onDone()
                }) { Text("Share code") }
            },
            dismissButton = { TextButton(onClick = { createdCode = null; onDone() }) { Text("Continue") } }
        )
    }
}

private fun ago(t: Long?, now: Long): String {
    if (t == null) return "no location yet"
    val m = (now - t) / 60_000
    return when {
        m < 1 -> "just now"
        m < 60 -> "$m min ago"
        m < 1440 -> "${m / 60} h ago"
        else -> "${m / 1440} d ago"
    }
}

@Composable
private fun MemberRow(m: Member, isMe: Boolean, selected: Boolean, now: Long, onClick: () -> Unit) {
    val t = m.updatedAt
    val fresh = m.sharing && t != null && now - t < 5 * 60_000L
    val dot = when {
        !m.sharing -> OffGrey
        fresh -> LiveGreen
        else -> StaleAmber
    }
    val subtitle = when {
        !m.sharing -> "Sharing paused"
        m.lat == null -> "Waiting for location…"
        else -> ago(t, now) + (m.battery?.let { " • $it%" + if (it <= 15) " low" else "" } ?: "")
    }
    val lowBattery = m.sharing && (m.battery ?: 100) <= 15
    val primary = MaterialTheme.colorScheme.primary
    Row(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) primary.copy(alpha = 0.12f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(avatarColor(m.name)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                m.name.trim().take(1).uppercase().ifEmpty { "?" },
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text((m.name + (if (isMe) " (You)" else "")), style = MaterialTheme.typography.titleMedium)
            Text(
                subtitle, fontSize = 13.sp,
                color = if (lowBattery) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
            )
        }
        PulseDot(dot, live = fresh)
    }
}

@Composable
fun MapScreen(
    onLeft: () -> Unit,
    onSignOut: () -> Unit,
    onChat: () -> Unit,
    onAddGroup: () -> Unit,
    onRoute: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val ids = Prefs.familyIds(ctx)
    if (ids.isEmpty()) return
    var fid by remember { mutableStateOf(Prefs.activeId(ctx)?.takeIf { it in ids } ?: ids.first()) }
    val myUid = Prefs.uid(ctx)
    val clipboard = LocalClipboardManager.current
    val membersFlow = remember(fid) { Repo.observeMembers(fid) }
    val members by membersFlow.collectAsState(initial = emptyList())
    var sharing by remember { mutableStateOf(Prefs.sharing(ctx)) }
    var trailOn by remember { mutableStateOf(Prefs.trailOn(ctx)) }
    var code by remember { mutableStateOf("") }
    var names by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    var confirmLeave by remember { mutableStateOf(false) }
    var showStartPrompt by remember { mutableStateOf(false) }
    var permDenied by remember { mutableStateOf(false) }
    var panelOpen by remember { mutableStateOf(true) }
    var fitTick by remember { mutableStateOf(0) }
    val seenFit = remember { intArrayOf(0) }
    val latestFlow = remember(fid) { Repo.observeLatestMessage(fid) }
    val latestMsg by latestFlow.collectAsState(initial = null)
    val unread = latestMsg?.let { it.uid != myUid && (it.ts ?: 0L) > Prefs.chatSeen(ctx, fid) } ?: false

    // map / selection state
    val centered = remember { booleanArrayOf(false) }
    var selectedUid by remember { mutableStateOf<String?>(null) }
    var focusTick by remember { mutableStateOf(0) }
    val seenTick = remember { intArrayOf(0) }
    val seenKey = remember { arrayOf("") }

    fun switchGroup(id: String) {
        fid = id
        Prefs.setActive(ctx, id)
        selectedUid = null
        centered[0] = false
        seenKey[0] = ""
    }

    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(15_000L)
            now = System.currentTimeMillis()
        }
    }
    LaunchedEffect(fid) { code = try { Repo.familyCode(fid) } catch (e: Exception) { "" } }
    LaunchedEffect(ids.joinToString(",")) { names = Repo.familyNames(ids) }
    // First visit: offer to start sharing (with a plain-words explanation) instead of a silent switch.
    LaunchedEffect(Unit) {
        if (!Prefs.sharing(ctx) && !Prefs.pausedByUser(ctx)) showStartPrompt = true
    }

    val bgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        // Sharing works with the foreground service even if "all the time" is denied.
        // "All the time" lets the service restart after a reboot.
    }
    val fgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
            LocationService.start(ctx)
            sharing = true
            Prefs.setPausedByUser(ctx, false)
            scope.launch { try { Repo.setSharingFlag(ctx, true) } catch (e: Exception) { } }
            if (Build.VERSION.SDK_INT >= 29) bgLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        } else {
            sharing = false
            permDenied = true
        }
    }

    val haptic = LocalHapticFeedback.current
    fun toggle(on: Boolean) {
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        if (on) {
            val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            fgLauncher.launch(perms.toTypedArray())
        } else {
            sharing = false
            Prefs.setPausedByUser(ctx, true)
            LocationService.stop(ctx)
            scope.launch { try { Repo.setSharingFlag(ctx, false) } catch (e: Exception) { } }
        }
    }

    val visible = members.filter { it.sharing && it.lat != null && it.lng != null }
    val liveCount = visible.count { (it.updatedAt ?: 0L) > now - 5 * 60_000L }
    val sorted = members.sortedWith(
        compareByDescending<Member> { it.uid == myUid }
            .thenByDescending { it.sharing }
            .thenBy { it.name.lowercase() }
    )
    val selMember = members.firstOrNull { it.uid == selectedUid }
    val dark = isSystemInDarkTheme()
    val statusColor by animateColorAsState(if (sharing) LiveGreen else OffGrey, label = "status")

    Column(Modifier.fillMaxSize()) {
        // ---------------- map
        Box(Modifier.fillMaxWidth().weight(1f)) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    val cfg = Configuration.getInstance()
                    cfg.userAgentValue = c.packageName
                    cfg.osmdroidBasePath = c.cacheDir
                    cfg.osmdroidTileCache = File(c.cacheDir, "tiles")
                    MapView(c).apply {
                        setTileSource(TileSourceFactory.MAPNIK)
                        setMultiTouchControls(true)
                        controller.setZoom(4.0)
                        controller.setCenter(GeoPoint(20.5937, 78.9629))
                    }
                },
                update = { map ->
                    map.overlayManager.tilesOverlay.setColorFilter(if (dark) TilesOverlay.INVERT_COLORS else null)
                    map.overlays.clear()

                    visible.forEach { m ->
                        val mk = Marker(map).apply {
                            position = GeoPoint(m.lat!!, m.lng!!)
                            title = m.name
                            icon = avatarIcon(map.context, m.name, avatarColor(m.name).toArgb())
                            snippet = ago(m.updatedAt, now) + (m.battery?.let { b -> " • $b%" } ?: "")
                            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                        }
                        map.overlays.add(mk)
                        if (m.uid == selectedUid) mk.showInfoWindow()
                    }
                    // Tapped member: jump to them, then keep following as their fresh location arrives.
                    visible.firstOrNull { it.uid == selectedUid }?.let { sel ->
                        val key = "${sel.lat}:${sel.lng}"
                        val newTap = seenTick[0] != focusTick
                        if (newTap || seenKey[0] != key) {
                            if (newTap) map.controller.setZoom(16.0)
                            map.controller.animateTo(GeoPoint(sel.lat!!, sel.lng!!))
                            seenTick[0] = focusTick
                            seenKey[0] = key
                        }
                    }
                    // "Everyone" button: zoom so all live members fit on screen.
                    if (seenFit[0] != fitTick) {
                        seenFit[0] = fitTick
                        val pts = visible.map { GeoPoint(it.lat!!, it.lng!!) }
                        if (pts.size == 1) {
                            map.controller.setZoom(16.0)
                            map.controller.animateTo(pts[0])
                        } else if (pts.size > 1) {
                            map.zoomToBoundingBox(BoundingBox.fromGeoPoints(pts), true, 120)
                        }
                    }
                    if (!centered[0] && visible.isNotEmpty() && selectedUid == null) {
                        centered[0] = true
                        map.controller.setZoom(15.0)
                        map.controller.setCenter(GeoPoint(visible[0].lat!!, visible[0].lng!!))
                    }
                    map.invalidate()
                }
            )
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.background.copy(alpha = 0.92f),
                shadowElevation = 4.dp,
                modifier = Modifier.align(Alignment.TopStart).padding(12.dp)
            ) {
                Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(if (liveCount > 0) LiveGreen else OffGrey))
                    Spacer(Modifier.width(8.dp))
                    Text("$liveCount of ${members.size} live", style = MaterialTheme.typography.labelLarge)
                }
            }
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.primary,
                shadowElevation = 4.dp,
                modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)
            ) {
                Row(
                    Modifier.clickable { onChat() }.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("💬  Chat", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.labelLarge)
                    if (unread) {
                        Spacer(Modifier.width(8.dp))
                        Box(Modifier.size(10.dp).clip(CircleShape).background(Color(0xFFFFC107)))
                    }
                }
            }
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.background.copy(alpha = 0.92f),
                shadowElevation = 4.dp,
                modifier = Modifier.align(Alignment.BottomStart).padding(12.dp)
            ) {
                Row(
                    Modifier.clickable {
                        selectedUid = null
                        fitTick += 1
                    }.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("👥  Everyone", style = MaterialTheme.typography.labelLarge)
                }
            }
            Text(
                "© OpenStreetMap contributors", fontSize = 10.sp, color = Color(0xFF333333),
                modifier = Modifier.align(Alignment.BottomEnd)
                    .background(Color.White.copy(alpha = 0.75f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }

        // ---------------- bottom panel
        Surface(
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            color = MaterialTheme.colorScheme.background,
            shadowElevation = 12.dp,
            modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp).animateContentSize()
        ) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp)) {
                // Handle: tap to collapse or expand the panel
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                        .clickable { panelOpen = !panelOpen }.padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        Modifier.width(44.dp).height(5.dp).clip(CircleShape)
                            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25f))
                    )
                }
                // Group tabs
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ids.forEach { id ->
                        GroupChip(names[id] ?: "Family", selected = id == fid) { switchGroup(id) }
                    }
                    GroupChip("+ Add group", selected = false) { onAddGroup() }
                }
                Spacer(Modifier.height(12.dp))

                if (!panelOpen) {
                    Text(
                        (if (sharing) "Sharing on" else "Sharing paused") + "  •  $liveCount of ${members.size} live",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }

                // Selected member: always on top so the route button is easy to reach
                if (selMember != null) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(Modifier.padding(start = 16.dp, end = 8.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(selMember.name, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "Replay their day: stops, speed and distance",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                                )
                            }
                            TextButton(onClick = {
                                RouteTarget.fid = fid
                                RouteTarget.uid = selMember.uid
                                RouteTarget.name = selMember.name
                                onRoute()
                            }) { Text("Route replay") }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }

                if (panelOpen) {
                // Sharing switch card: glows with the brand gradient while sharing is on
                val onCard = if (sharing) Color.White else MaterialTheme.colorScheme.onSurface
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(
                        if (sharing) Brush.horizontalGradient(listOf(BrandStart, BrandEnd))
                        else SolidColor(MaterialTheme.colorScheme.surfaceVariant)
                    )
                ) {
                    Column {
                        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(12.dp).clip(CircleShape).background(statusColor))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    if (sharing) "Sharing is on" else "Sharing is paused",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = onCard
                                )
                                Text(
                                    if (sharing) "Your groups can see you live" else "Nobody can see your location",
                                    fontSize = 13.sp,
                                    color = onCard.copy(alpha = 0.8f)
                                )
                            }
                            Switch(
                                sharing, { toggle(it) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color.White.copy(alpha = 0.35f),
                                    checkedBorderColor = Color.White.copy(alpha = 0.6f)
                                )
                            )
                        }
                        Row(
                            Modifier.padding(start = 40.dp, end = 16.dp, bottom = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Record my route for family",
                                Modifier.weight(1f), fontSize = 13.sp,
                                color = onCard.copy(alpha = 0.85f)
                            )
                            Switch(
                                trailOn, { trailOn = it; Prefs.setTrailOn(ctx, it) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color.White.copy(alpha = 0.35f),
                                    checkedBorderColor = Color.White.copy(alpha = 0.6f)
                                )
                            )
                        }
                    }
                }

                // Members
                Spacer(Modifier.height(14.dp))
                Text(names[fid] ?: "Family", style = MaterialTheme.typography.titleLarge)
                Text(
                    "Tap a name to see them on the map",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
                Spacer(Modifier.height(4.dp))
                sorted.forEach { m ->
                    MemberRow(m, isMe = m.uid == myUid, selected = m.uid == selectedUid, now = now) {
                        when {
                            !m.sharing ->
                                Toast.makeText(ctx, "${m.name} has paused sharing", Toast.LENGTH_SHORT).show()
                            m.lat == null ->
                                Toast.makeText(ctx, "No location from ${m.name} yet", Toast.LENGTH_SHORT).show()
                            else -> {
                                // Show them on the map right away, and refresh their position in the background.
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                selectedUid = m.uid
                                focusTick += 1
                                scope.launch {
                                    try { Repo.requestRefresh(fid, m.uid) } catch (e: Exception) { }
                                }
                            }
                        }
                    }
                }
                if (members.none { it.uid != myUid }) {
                    Text(
                        "You're the only one here so far. Share the invite code below with your family.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }

                // Invite
                Spacer(Modifier.height(10.dp))
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(Modifier.padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Invite code", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                            Text(
                                if (code.isEmpty()) "…" else code,
                                fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp
                            )
                        }
                        TextButton(enabled = code.isNotEmpty(), onClick = {
                            clipboard.setText(AnnotatedString(code))
                            Toast.makeText(ctx, "Code copied", Toast.LENGTH_SHORT).show()
                        }) { Text("Copy") }
                        TextButton(enabled = code.isNotEmpty(), onClick = {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(
                                    Intent.EXTRA_TEXT,
                                    "Join our family on Family Locator. Install the app and use this code: $code"
                                )
                            }
                            ctx.startActivity(Intent.createChooser(send, "Invite family"))
                        }) { Text("Share") }
                    }
                }

                if (sharing) {
                    TextButton(onClick = {
                        ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    }) { Text("Keep sharing reliable (battery settings)") }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = { confirmLeave = true }) {
                        Text("Leave this group", color = MaterialTheme.colorScheme.error)
                    }
                    TextButton(onClick = {
                        scope.launch {
                            try { Repo.setSharingFlag(ctx, false) } catch (e: Exception) { }
                            LocationService.stop(ctx, silent = true)
                            Repo.signOut(ctx)
                            onSignOut()
                        }
                    }) { Text("Sign out") }
                }
                } // end panelOpen
            }
        }
    }

    if (confirmLeave) {
        AlertDialog(
            onDismissRequest = { confirmLeave = false },
            title = { Text("Leave ${names[fid] ?: "this group"}?") },
            text = { Text("Your location and route history will be removed from this group. Your other groups are not affected.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmLeave = false
                    scope.launch {
                        try {
                            Repo.leaveFamily(ctx, fid)
                        } catch (e: Exception) {
                            Toast.makeText(ctx, "Couldn't leave. Check your internet.", Toast.LENGTH_SHORT).show()
                            return@launch
                        }
                        val left = Prefs.familyIds(ctx)
                        if (left.isEmpty()) {
                            LocationService.stop(ctx, silent = true)
                            onLeft()
                        } else {
                            if (Prefs.sharing(ctx)) LocationService.start(ctx)
                            switchGroup(left.first())
                        }
                    }
                }) { Text("Leave", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmLeave = false }) { Text("Cancel") } }
        )
    }

    if (showStartPrompt) {
        AlertDialog(
            onDismissRequest = { showStartPrompt = false },
            title = { Text("Start sharing with your family?") },
            text = {
                Text(
                    "Your live location will be shared with your family groups, even when the app is closed. " +
                        "Android will now ask for permission. Please choose \"Allow all the time\" and allow notifications. " +
                        "You can pause any time from this screen."
                )
            },
            confirmButton = {
                TextButton(onClick = { showStartPrompt = false; toggle(true) }) { Text("Start sharing") }
            },
            dismissButton = {
                TextButton(onClick = {
                    showStartPrompt = false
                    Prefs.setPausedByUser(ctx, true)
                }) { Text("Not now") }
            }
        )
    }

    if (permDenied) {
        AlertDialog(
            onDismissRequest = { permDenied = false },
            title = { Text("Location permission needed") },
            text = {
                Text(
                    "Without location permission your family can't see you. Tap Open settings, then " +
                        "Permissions, Location, and choose \"Allow all the time\"."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    permDenied = false
                    ctx.startActivity(
                        Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            android.net.Uri.parse("package:" + ctx.packageName)
                        )
                    )
                }) { Text("Open settings") }
            },
            dismissButton = { TextButton(onClick = { permDenied = false }) { Text("Later") } }
        )
    }
}
