package com.familyloc.app

import android.Manifest
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import java.io.File

@Composable
fun App() {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf(Screen.Loading) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        screen = try { Repo.initialScreen(ctx) } catch (e: Exception) { Screen.Auth }
    }

    when (screen) {
        Screen.Loading -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally) { Text("Loading…") }
        Screen.Auth -> AuthScreen { scope.launch { screen = Repo.initialScreen(ctx) } }
        Screen.Consent -> ConsentScreen { screen = Screen.Family }
        Screen.Family -> FamilyScreen { screen = Screen.Map }
        Screen.Map -> MapScreen(onLeft = { screen = Screen.Family }, onSignOut = {
            LocationService.stop(ctx)
            Repo.signOut(ctx)
            screen = Screen.Auth
        })
    }
}

@Composable
fun AuthScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isSignUp by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Family Locator", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Private location sharing for your family only.")
        Column(Modifier.height(16.dp)) {}
        if (isSignUp) {
            OutlinedTextField(name, { name = it }, label = { Text("Your name") }, modifier = Modifier.fillMaxWidth())
        }
        OutlinedTextField(email, { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(password, { password = it }, label = { Text("Password (6+ characters)") },
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(
            enabled = !busy && email.isNotBlank() && password.length >= 6 && (!isSignUp || name.isNotBlank()),
            onClick = {
                busy = true; error = null
                scope.launch {
                    try {
                        if (isSignUp) Repo.signUp(ctx, name, email, password) else Repo.signIn(email, password)
                        onDone()
                    } catch (e: Exception) {
                        error = e.message
                    }
                    busy = false
                }
            },
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
        ) { Text(if (isSignUp) "Create account" else "Sign in") }
        TextButton(onClick = { isSignUp = !isSignUp }) {
            Text(if (isSignUp) "I already have an account" else "Create a new account")
        }
    }
}

@Composable
fun ConsentScreen(onAgree: () -> Unit) {
    val scope = rememberCoroutineScope()
    var agreed by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState())) {
        Text("Your consent", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(
            "\nIf you agree, this app will:\n\n" +
                "• Share this phone's live location with the members of your family group, including while the app is closed.\n" +
                "• Show a permanent notification while sharing is on.\n" +
                "• Share your battery level.\n\n" +
                "You stay in control:\n\n" +
                "• Pause or resume sharing any time from the app or the notification.\n" +
                "• Leave the family group to delete your location data.\n" +
                "• Only people who have your family code can join, and only members can see locations.\n"
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(agreed, { agreed = it })
            Text("I understand and agree to share my location with my family group.")
        }
        Button(enabled = agreed, onClick = { scope.launch { Repo.saveConsent(); onAgree() } },
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) { Text("I agree") }
    }
}

@Composable
fun FamilyScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var familyName by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Your family group", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("\nStart a new group:")
        OutlinedTextField(familyName, { familyName = it }, label = { Text("Family name") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = familyName.isNotBlank(), onClick = {
            scope.launch {
                try { Repo.createFamily(ctx, familyName); onDone() } catch (e: Exception) { error = e.message }
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Create group") }

        Text("\nOr join with a code from a family member:")
        OutlinedTextField(code, { code = it }, label = { Text("6-character code") }, modifier = Modifier.fillMaxWidth())
        OutlinedButton(enabled = code.length >= 6, onClick = {
            scope.launch {
                try { Repo.joinFamily(ctx, code); onDone() } catch (e: Exception) { error = e.message }
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Join group") }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}

private fun ago(t: Long?): String {
    if (t == null) return "no location yet"
    val m = (System.currentTimeMillis() - t) / 60_000
    return when {
        m < 1 -> "just now"
        m < 60 -> "$m min ago"
        m < 1440 -> "${m / 60} h ago"
        else -> "${m / 1440} d ago"
    }
}

@Composable
fun MapScreen(onLeft: () -> Unit, onSignOut: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val fid = Prefs.familyId(ctx) ?: return
    val members by Repo.observeMembers(fid).collectAsState(initial = emptyList())
    var sharing by remember { mutableStateOf(Prefs.sharing(ctx)) }
    var code by remember { mutableStateOf("") }
    LaunchedEffect(fid) { code = try { Repo.familyCode(fid) } catch (e: Exception) { "" } }

    val bgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        // Sharing works with the foreground service even if "all the time" is denied.
        // "All the time" lets the service restart after a reboot.
    }
    val fgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
            LocationService.start(ctx)
            sharing = true
            scope.launch { Repo.setSharingFlag(ctx, true) }
            if (Build.VERSION.SDK_INT >= 29) bgLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        } else sharing = false
    }

    fun toggle(on: Boolean) {
        if (on) {
            val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            fgLauncher.launch(perms.toTypedArray())
        } else {
            sharing = false
            LocationService.stop(ctx)
            scope.launch { Repo.setSharingFlag(ctx, false) }
        }
    }

    val visible = members.filter { it.sharing && it.lat != null && it.lng != null }
    val centered = remember { booleanArrayOf(false) }

    Column(Modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.fillMaxWidth().weight(1f),
            factory = { c ->
                val cfg = Configuration.getInstance()
                cfg.userAgentValue = c.packageName
                cfg.osmdroidBasePath = c.cacheDir
                cfg.osmdroidTileCache = File(c.cacheDir, "tiles")
                MapView(c).apply {
                    setTileSource(TileSourceFactory.MAPNIK)
                    setMultiTouchControls(true)
                    controller.setZoom(4.0)
                    controller.setCenter(GeoPoint(20.5937, 78.9629))
                }
            },
            update = { map ->
                map.overlays.clear()
                visible.forEach { m ->
                    map.overlays.add(Marker(map).apply {
                        position = GeoPoint(m.lat!!, m.lng!!)
                        title = m.name
                        snippet = ago(m.updatedAt) + (m.battery?.let { b -> " • $b%" } ?: "")
                        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                    })
                }
                if (!centered[0] && visible.isNotEmpty()) {
                    centered[0] = true
                    map.controller.setZoom(15.0)
                    map.controller.setCenter(GeoPoint(visible[0].lat!!, visible[0].lng!!))
                }
                map.invalidate()
            }
        )
        Column(Modifier.weight(1f).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Share my location", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                Switch(sharing, { toggle(it) })
            }
            Text("Family code: $code", fontSize = 14.sp)
            LazyColumn(Modifier.weight(1f).padding(vertical = 8.dp)) {
                items(members) { m ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Text(m.name, Modifier.weight(1f), fontWeight = FontWeight.Medium)
                        Text(if (m.sharing) ago(m.updatedAt) + (m.battery?.let { " • $it%" } ?: "") else "paused")
                    }
                }
            }
            if (sharing && Build.VERSION.SDK_INT >= 23) {
                TextButton(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }) { Text("Keep sharing reliable (battery settings)") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    scope.launch {
                        LocationService.stop(ctx)
                        Repo.leaveFamily(ctx)
                        onLeft()
                    }
                }) { Text("Leave group") }
                OutlinedButton(onClick = onSignOut) { Text("Sign out") }
            }
        }
    }
}
