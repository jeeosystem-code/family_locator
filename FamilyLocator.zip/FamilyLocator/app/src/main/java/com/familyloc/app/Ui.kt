package com.familyloc.app

import android.Manifest
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.TilesOverlay
import java.io.File

private val AvatarColors = listOf(
    Color(0xFF0F766E), Color(0xFF7C3AED), Color(0xFFDB2777),
    Color(0xFFEA580C), Color(0xFF2563EB), Color(0xFF16A34A)
)
private val LiveGreen = Color(0xFF16A34A)
private val StaleAmber = Color(0xFFF59E0B)
private val OffGrey = Color(0xFF9CA3AF)

private fun avatarColor(name: String) = AvatarColors[(name.hashCode() and 0x7fffffff) % AvatarColors.size]

/** Round initial-letter map marker with a small tail, matching the family list avatars. */
private fun avatarIcon(ctx: android.content.Context, name: String, argb: Int): android.graphics.drawable.Drawable {
    val d = ctx.resources.displayMetrics.density
    val size = (44 * d).toInt()
    val tail = (9 * d).toInt()
    val bmp = android.graphics.Bitmap.createBitmap(size, size + tail, android.graphics.Bitmap.Config.ARGB_8888)
    val cv = android.graphics.Canvas(bmp)
    val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    val r = size / 2f
    p.color = android.graphics.Color.WHITE
    cv.drawCircle(r, r, r, p)
    val tri = android.graphics.Path().apply {
        moveTo(r - 7 * d, size - 4 * d)
        lineTo(r + 7 * d, size - 4 * d)
        lineTo(r, size + tail.toFloat())
        close()
    }
    cv.drawPath(tri, p)
    p.color = argb
    cv.drawCircle(r, r, r - 3 * d, p)
    p.color = android.graphics.Color.WHITE
    p.textSize = 18 * d
    p.typeface = android.graphics.Typeface.DEFAULT_BOLD
    p.textAlign = android.graphics.Paint.Align.CENTER
    val y = r - (p.descent() + p.ascent()) / 2
    cv.drawText(name.trim().take(1).uppercase().ifEmpty { "?" }, r, y, p)
    return android.graphics.drawable.BitmapDrawable(ctx.resources, bmp)
}

// ---------------------------------------------------------------- app shell

@Composable
fun App() {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf(Screen.Loading) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        screen = try { Repo.initialScreen(ctx) } catch (e: Exception) { Screen.Auth }
    }

    Crossfade(targetState = screen, label = "screen") { s ->
        when (s) {
            Screen.Loading -> LoadingScreen()
            Screen.Auth -> AuthScreen {
                scope.launch {
                    screen = try { Repo.initialScreen(ctx) } catch (e: Exception) { Screen.Auth }
                }
            }
            Screen.Consent -> ConsentScreen { screen = Screen.Family }
            Screen.Family -> FamilyScreen { screen = Screen.Map }
            Screen.Map -> MapScreen(onLeft = { screen = Screen.Family }, onSignOut = { screen = Screen.Auth })
        }
    }
}

// ---------------------------------------------------------------- shared pieces

@Composable
private fun BrandHeader(subtitle: String) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Image(painterResource(R.drawable.ic_logo), contentDescription = null, modifier = Modifier.size(88.dp))
        Spacer(Modifier.height(4.dp))
        Text(
            "Family Locator",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(4.dp))
        Text(
            subtitle,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun PrimaryButton(text: String, enabled: Boolean = true, busy: Boolean = false, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled && !busy,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().height(52.dp)
    ) {
        if (busy) {
            CircularProgressIndicator(
                Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary
            )
        } else {
            Text(text, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
private fun Field(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    keyboard: KeyboardOptions = KeyboardOptions.Default,
    password: Boolean = false
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        keyboardOptions = keyboard,
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(body, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f))
        }
    }
}

private fun friendly(e: Exception): String {
    val m = (e.message ?: return "Something went wrong. Please try again.")
    val l = m.lowercase()
    return when {
        "network" in l -> "No internet connection. Please check and try again."
        "already in use" in l -> "This email already has an account. Try signing in instead."
        "password is invalid" in l || "no user record" in l || "credential" in l -> "Wrong email or password."
        "badly formatted" in l -> "Please enter a valid email address."
        else -> m
    }
}

// ---------------------------------------------------------------- screens

@Composable
fun LoadingScreen() {
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(painterResource(R.drawable.ic_logo), contentDescription = null, modifier = Modifier.size(96.dp))
        Spacer(Modifier.height(16.dp))
        CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
    }
}

@Composable
fun AuthScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isSignUp by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).imePadding().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        BrandHeader("Private location sharing,\nfor your family only.")
        Spacer(Modifier.height(28.dp))
        Text(
            if (isSignUp) "Create your account" else "Welcome back",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        if (isSignUp) {
            Field(name, { name = it }, "Your name", KeyboardOptions(capitalization = KeyboardCapitalization.Words))
            Spacer(Modifier.height(10.dp))
        }
        Field(email, { email = it }, "Email", KeyboardOptions(keyboardType = KeyboardType.Email))
        Spacer(Modifier.height(10.dp))
        Field(
            password, { password = it }, "Password (6+ characters)",
            KeyboardOptions(keyboardType = KeyboardType.Password), password = true
        )
        error?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(18.dp))
        PrimaryButton(
            text = if (isSignUp) "Create account" else "Sign in",
            enabled = email.isNotBlank() && password.length >= 6 && (!isSignUp || name.isNotBlank()),
            busy = busy
        ) {
            busy = true; error = null
            scope.launch {
                try {
                    if (isSignUp) Repo.signUp(ctx, name, email, password) else Repo.signIn(email, password)
                    onDone()
                } catch (e: Exception) {
                    error = friendly(e)
                }
                busy = false
            }
        }
        Spacer(Modifier.height(4.dp))
        TextButton(onClick = { isSignUp = !isSignUp; error = null }) {
            Text(if (isSignUp) "I already have an account" else "Create a new account")
        }
    }
}

@Composable
fun ConsentScreen(onAgree: () -> Unit) {
    val scope = rememberCoroutineScope()
    var agreed by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Your consent", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Please read this before you start. You decide what is shared.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
            InfoCard(
                "Shared with family only",
                "Your live location and battery level are shared with the members of your family group, even when the app is closed."
            )
            InfoCard(
                "A notification stays on",
                "While sharing is on, a notification is always visible so you know it is running."
            )
            InfoCard(
                "You stay in control",
                "Pause or resume any time from the app or the notification. Leave the group to remove your location data."
            )
            InfoCard(
                "Invite-only",
                "Only people who have your family code can join, and only members can see locations."
            )
        }
        Column(Modifier.padding(horizontal = 24.dp, vertical = 12.dp)) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { agreed = !agreed },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(agreed, { agreed = it })
                Text("I understand and agree to share my location with my family group.", Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            PrimaryButton("I agree", enabled = agreed, busy = busy) {
                busy = true
                scope.launch {
                    try { Repo.saveConsent(); onAgree() } catch (e: Exception) { busy = false }
                }
            }
        }
    }
}

@Composable
fun FamilyScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var familyName by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busyCreate by remember { mutableStateOf(false) }
    var busyJoin by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).imePadding().padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        BrandHeader("Create your family group, or join one with a code.")
        Spacer(Modifier.height(24.dp))

        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("Start a new group", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(10.dp))
                Field(familyName, { familyName = it }, "Family name", KeyboardOptions(capitalization = KeyboardCapitalization.Words))
                Spacer(Modifier.height(12.dp))
                PrimaryButton("Create group", enabled = familyName.isNotBlank(), busy = busyCreate) {
                    busyCreate = true; error = null
                    scope.launch {
                        try { Repo.createFamily(ctx, familyName); onDone() } catch (e: Exception) { error = friendly(e) }
                        busyCreate = false
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("Join with a code", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(10.dp))
                Field(
                    code, { code = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(6) },
                    "6-character code",
                    KeyboardOptions(capitalization = KeyboardCapitalization.Characters)
                )
                Spacer(Modifier.height(12.dp))
                PrimaryButton("Join group", enabled = code.length == 6, busy = busyJoin) {
                    busyJoin = true; error = null
                    scope.launch {
                        try { Repo.joinFamily(ctx, code); onDone() } catch (e: Exception) { error = friendly(e) }
                        busyJoin = false
                    }
                }
            }
        }
        error?.let {
            Spacer(Modifier.height(10.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }
    }
}

private fun ago(t: Long?, now: Long): String {
    if (t == null) return "no location yet"
    val m = (now - t) / 60_000
    return when {
        m < 1 -> "just now"
        m < 60 -> "$m min ago"
        m < 1440 -> "${m / 60} h ago"
        else -> "${m / 1440} d ago"
    }
}

@Composable
private fun MemberRow(m: Member, isMe: Boolean, selected: Boolean, now: Long, onClick: () -> Unit) {
    val t = m.updatedAt
    val fresh = m.sharing && t != null && now - t < 5 * 60_000L
    val dot = when {
        !m.sharing -> OffGrey
        fresh -> LiveGreen
        else -> StaleAmber
    }
    val subtitle = when {
        !m.sharing -> "Sharing paused"
        m.lat == null -> "Waiting for location…"
        else -> ago(t, now) + (m.battery?.let { " • $it%" } ?: "")
    }
    val primary = MaterialTheme.colorScheme.primary
    Row(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) primary.copy(alpha = 0.12f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(44.dp).clip(CircleShape)
                .background(AvatarColors[(m.name.hashCode() and 0x7fffffff) % AvatarColors.size]),
            contentAlignment = Alignment.Center
        ) {
            Text(
                m.name.trim().take(1).uppercase().ifEmpty { "?" },
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text((m.name + (if (isMe) " (You)" else "")), style = MaterialTheme.typography.titleMedium)
            Text(
                subtitle, fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
            )
        }
        Box(Modifier.size(10.dp).clip(CircleShape).background(dot))
    }
}

@Composable
fun MapScreen(onLeft: () -> Unit, onSignOut: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val fid = Prefs.familyId(ctx) ?: return
    val myUid = Prefs.uid(ctx)
    val clipboard = LocalClipboardManager.current
    val membersFlow = remember(fid) { Repo.observeMembers(fid) }
    val members by membersFlow.collectAsState(initial = emptyList())
    var sharing by remember { mutableStateOf(Prefs.sharing(ctx)) }
    var code by remember { mutableStateOf("") }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    var confirmLeave by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(15_000L)
            now = System.currentTimeMillis()
        }
    }
    LaunchedEffect(fid) { code = try { Repo.familyCode(fid) } catch (e: Exception) { "" } }

    val bgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        // Sharing works with the foreground service even if "all the time" is denied.
        // "All the time" lets the service restart after a reboot.
    }
    val fgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
            LocationService.start(ctx)
            sharing = true
            scope.launch { Repo.setSharingFlag(ctx, true) }
            if (Build.VERSION.SDK_INT >= 29) bgLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        } else sharing = false
    }

    fun toggle(on: Boolean) {
        if (on) {
            val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            fgLauncher.launch(perms.toTypedArray())
        } else {
            sharing = false
            LocationService.stop(ctx)
            scope.launch { Repo.setSharingFlag(ctx, false) }
        }
    }

    val visible = members.filter { it.sharing && it.lat != null && it.lng != null }
    val liveCount = visible.count { (it.updatedAt ?: 0L) > now - 5 * 60_000L }
    val sorted = members.sortedWith(
        compareByDescending<Member> { it.uid == myUid }
            .thenByDescending { it.sharing }
            .thenBy { it.name.lowercase() }
    )
    val centered = remember { booleanArrayOf(false) }
    var selectedUid by remember { mutableStateOf<String?>(null) }
    var focusTick by remember { mutableStateOf(0) }
    val seenTick = remember { intArrayOf(0) }
    val seenKey = remember { arrayOf("") }

    val dark = isSystemInDarkTheme()
    val statusColor by animateColorAsState(if (sharing) LiveGreen else OffGrey, label = "status")

    Column(Modifier.fillMaxSize()) {
        // ---------------- map
        Box(Modifier.fillMaxWidth().weight(1f)) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    val cfg = Configuration.getInstance()
                    cfg.userAgentValue = c.packageName
                    cfg.osmdroidBasePath = c.cacheDir
                    cfg.osmdroidTileCache = File(c.cacheDir, "tiles")
                    MapView(c).apply {
                        setTileSource(TileSourceFactory.MAPNIK)
                        setMultiTouchControls(true)
                        controller.setZoom(4.0)
                        controller.setCenter(GeoPoint(20.5937, 78.9629))
                    }
                },
                update = { map ->
                    map.overlayManager.tilesOverlay.setColorFilter(if (dark) TilesOverlay.INVERT_COLORS else null)
                    map.overlays.clear()
                    visible.forEach { m ->
                        val mk = Marker(map).apply {
                            position = GeoPoint(m.lat!!, m.lng!!)
                            title = m.name
                            icon = avatarIcon(map.context, m.name, avatarColor(m.name).toArgb())
                            snippet = ago(m.updatedAt, now) + (m.battery?.let { b -> " • $b%" } ?: "")
                            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                        }
                        map.overlays.add(mk)
                        if (m.uid == selectedUid) mk.showInfoWindow()
                    }
                    // Tapped member: jump to them, then keep following as their fresh location arrives.
                    visible.firstOrNull { it.uid == selectedUid }?.let { sel ->
                        val key = "${sel.lat}:${sel.lng}"
                        val newTap = seenTick[0] != focusTick
                        if (newTap || seenKey[0] != key) {
                            if (newTap) map.controller.setZoom(16.0)
                            map.controller.animateTo(GeoPoint(sel.lat!!, sel.lng!!))
                            seenTick[0] = focusTick
                            seenKey[0] = key
                        }
                    }
                    if (!centered[0] && visible.isNotEmpty() && selectedUid == null) {
                        centered[0] = true
                        map.controller.setZoom(15.0)
                        map.controller.setCenter(GeoPoint(visible[0].lat!!, visible[0].lng!!))
                    }
                    map.invalidate()
                }
            )
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.background.copy(alpha = 0.92f),
                shadowElevation = 4.dp,
                modifier = Modifier.align(Alignment.TopStart).padding(12.dp)
            ) {
                Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(if (liveCount > 0) LiveGreen else OffGrey))
                    Spacer(Modifier.width(8.dp))
                    Text("$liveCount of ${members.size} live", style = MaterialTheme.typography.labelLarge)
                }
            }
            Text(
                "© OpenStreetMap contributors", fontSize = 10.sp, color = Color(0xFF333333),
                modifier = Modifier.align(Alignment.BottomEnd)
                    .background(Color.White.copy(alpha = 0.75f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }

        // ---------------- bottom panel
        Surface(
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            color = MaterialTheme.colorScheme.background,
            shadowElevation = 12.dp,
            modifier = Modifier.fillMaxWidth().heightIn(max = 400.dp)
        ) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp)) {
                // Sharing switch card
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(12.dp).clip(CircleShape).background(statusColor))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                if (sharing) "Sharing is on" else "Sharing is paused",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                if (sharing) "Your family can see you live" else "Nobody can see your location",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                            )
                        }
                        Switch(sharing, { toggle(it) })
                    }
                }

                // Members
                Spacer(Modifier.height(14.dp))
                Text("Family", style = MaterialTheme.typography.titleLarge)
                Text(
                    "Tap a name to see them on the map",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
                Spacer(Modifier.height(4.dp))
                sorted.forEach { m ->
                    MemberRow(m, isMe = m.uid == myUid, selected = m.uid == selectedUid, now = now) {
                        when {
                            !m.sharing ->
                                Toast.makeText(ctx, "${m.name} has paused sharing", Toast.LENGTH_SHORT).show()
                            m.lat == null ->
                                Toast.makeText(ctx, "No location from ${m.name} yet", Toast.LENGTH_SHORT).show()
                            else -> {
                                // Show them on the map right away, and refresh their position in the background.
                                selectedUid = m.uid
                                focusTick += 1
                                scope.launch {
                                    try { Repo.requestRefresh(ctx, m.uid) } catch (e: Exception) { }
                                }
                            }
                        }
                    }
                }
                if (members.none { it.uid != myUid }) {
                    Text(
                        "You're the only one here so far. Share the invite code below with your family.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }

                // Invite
                Spacer(Modifier.height(10.dp))
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(Modifier.padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Invite code", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
                            Text(
                                if (code.isEmpty()) "…" else code,
                                fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp
                            )
                        }
                        TextButton(enabled = code.isNotEmpty(), onClick = {
                            clipboard.setText(AnnotatedString(code))
                            Toast.makeText(ctx, "Code copied", Toast.LENGTH_SHORT).show()
                        }) { Text("Copy") }
                        TextButton(enabled = code.isNotEmpty(), onClick = {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(
                                    Intent.EXTRA_TEXT,
                                    "Join our family on Family Locator. Install the app and use this code: $code"
                                )
                            }
                            ctx.startActivity(Intent.createChooser(send, "Invite family"))
                        }) { Text("Share") }
                    }
                }

                if (sharing) {
                    TextButton(onClick = {
                        ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    }) { Text("Keep sharing reliable (battery settings)") }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = { confirmLeave = true }) {
                        Text("Leave group", color = MaterialTheme.colorScheme.error)
                    }
                    TextButton(onClick = {
                        scope.launch {
                            try { Repo.setSharingFlag(ctx, false) } catch (e: Exception) { }
                            LocationService.stop(ctx, silent = true)
                            Repo.signOut(ctx)
                            onSignOut()
                        }
                    }) { Text("Sign out") }
                }
            }
        }
    }

    if (confirmLeave) {
        AlertDialog(
            onDismissRequest = { confirmLeave = false },
            title = { Text("Leave this family?") },
            text = { Text("Your location will stop being shared and your data will be removed from the group.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmLeave = false
                    scope.launch {
                        LocationService.stop(ctx, silent = true)
                        Repo.leaveFamily(ctx)
                        onLeft()
                    }
                }) { Text("Leave", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmLeave = false }) { Text("Cancel") } }
        )
    }
}
