# Family Locator (Android)

Private, consent-based live location sharing for your family. Kotlin + Jetpack Compose + Firebase + Google Maps.

**Status:** code written but not compiled or tested here (no Android SDK / network in this workspace). Expect to fix small build errors on first run in Android Studio.

## How it behaves
- Each person creates an account, reads and accepts a consent screen, then creates or joins a family group with a 6-character code.
- Sharing is a foreground service: runs 24/7 with a permanent notification (Android requires this), updates every ~30 s or 10 m of movement.
- Anyone can pause (switch or notification button) or leave the group, which deletes their location.
- Only group members can read locations (see `firestore.rules`).

## Setup
1. Create a Firebase project. Add an Android app with package `com.familyloc.app`. Download `google-services.json` into `app/`.
2. Firebase console: enable Authentication → Email/Password; create a Firestore database; paste `firestore.rules` into Rules and publish.
3. Maps use free OpenStreetMap: no API key or billing needed.
4. Build with Android Studio, or push to GitHub and run the "Build APK" workflow (add repo secret `GOOGLE_SERVICES_JSON` with the file's full text). Install the APK on each family phone.
5. On each phone: allow Location "All the time", notifications, and set battery to "Unrestricted" (Xiaomi, Oppo, Vivo, Samsung may otherwise kill the service).

## Notes
- Distribute the APK directly to family. Publishing on Google Play requires a background-location declaration and review.
- Only install it on phones of people who have agreed. Do not use it to track anyone without their knowledge.
- Duplicate invite codes are unlikely but not checked; add a uniqueness check before wider use.
