# Family Locator (Android)

Private, consent-based live location sharing for your family. Kotlin + Jetpack Compose + Firebase + free OpenStreetMap.

**Status:** code written but not compiled or tested in the authoring workspace (no Android SDK / network). Build with the GitHub "Build APK" workflow or Android Studio and expect to fix small errors on first run.

## Features
- Sign-up, consent screen, invite codes, **several groups per person** (Family, Relatives, Friends) with tabs.
- Foreground service shares live location every ~1 minute to all of a person's groups, with a permanent notification; pause or leave any time.
- Tap a name: map jumps to that person and their phone sends a fresh location.
- **Route history:** "Today's route" draws where a member went today (distance shown). Each person can switch off "Record my route".
- **Family chat** per group with quick replies ("I reached home"). New messages notify while sharing is on.
- Dark mode, avatars, invite sharing.

## Setup
1. Firebase project, Android app `com.familyloc.app`, `google-services.json` in `app/` (or GitHub secret `GOOGLE_SERVICES_JSON`).
2. Authentication: enable Email/Password. Firestore: create database, paste `firestore.rules`, Publish.
3. Build the APK (GitHub Actions workflow in `.github/workflows/build.yml`, or Android Studio) and install on each phone.
4. On each phone: Location "All the time", notifications, battery "Unrestricted".

## Data and limits
- Firestore free plan: about 20,000 writes/day. Live location is one write per minute per person per group, route points are sparse (moved 50 m+ or every 10 min). Roughly 4–6 people in 1–2 groups fit; more may hit the daily limit (resets daily).
- Leaving a group deletes that person's live location and route history for it. Chat messages stay in the group.
- Push notifications for chat come from the running sharing service, so they need sharing to be on.
- Distribute the APK directly; Google Play needs a background-location review.
- Only use with people who have agreed.
